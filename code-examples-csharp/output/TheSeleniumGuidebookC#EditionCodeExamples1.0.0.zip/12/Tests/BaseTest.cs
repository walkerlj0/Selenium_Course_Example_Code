﻿using System.Configuration;
using OpenQA.Selenium;
using NUnit.Framework;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;

namespace Tests
{
    [TestFixture]
    class BaseTest
    {
        protected IWebDriver Driver;
        public static string ApplicationBaseUrl;
        private static string BrowserName;
        private static string VendorDirectory;

        private void LoadConfigValues()
        {
            var configReader    = new AppSettingsReader();
            BrowserName         = (string)configReader.GetValue("BrowserName", typeof(string));
            ApplicationBaseUrl  = (string)configReader.GetValue("ApplicationBaseUrl", typeof(string));
            VendorDirectory     = System.IO.Directory.GetParent(
                                  System.IO.Path.GetDirectoryName(
                                  typeof(Tests.BaseTest).Assembly.Location)).
                              	  Parent.FullName + @"\Vendor";
        }

        [SetUp]
        protected void SetUp()
        {
            LoadConfigValues();
            switch (BrowserName.ToLower())
            {
                case "firefox":
                    Driver = new FirefoxDriver();
                    break;
                case "chrome":
                    Driver = new ChromeDriver(VendorDirectory);
                    break;
            }
        }

        [TearDown]
        protected void TearDown()
        {
            Driver.Quit();
        }
    }
}